# Quick Start 🚀
```npm install```<br>
```npm start  or  nodemon index.js```<br>


# What I Learned 🧠
* Node.js basics (async programming, callbacks, anonymous and arrow functions, server side stuff, imports, modules, express, http, path, socket.io)
* Web Sockets
* HTTP/HTTPS
* DOM manipulation, EventListeners, Forms
* How to use CSS Framework
* Simple media queries
* npm basics
* Gathering front-end and back-end together